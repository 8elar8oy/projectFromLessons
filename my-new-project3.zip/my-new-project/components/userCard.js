import styles from './userCard.module.css';
import { bottom } from "./bottom";
import { removeUser } from "../api/removeUser.js";

// let userId = null
// const removUserCallBack = () => {
//     console.log(userId)
//     removeUser('users', userId)
// }

export const userCard = user => {
    const div = document.createElement('div');
    const name = document.createElement('p');
    const login = document.createElement('p');
    const email = document.createElement('p');

    const btnSend = bottom('удалить')
    btnSend.addEventListener('click', () => {
        removeUser('users', user.id).then((res) => {
            const removeItem = document.getElementById(res.data.id)
            const userContainer = document.getElementById('userContainer')
            userContainer.removeChild(removeItem)
        })
    })
    const btnEdit = bottom('редактировать')
    btnEdit.addEventListener('click', () => {

    })

    div.setAttribute('id', user.id)
    div.classList.add(styles.container);
    name.classList.add(styles.name);
    btnSend.classList.add(styles.btn)
    btnEdit.classList.add(styles.btn)
    name.innerText = user.name;
    login.innerText = user.username;
    email.innerText = user.email;
    div.append(name, login, email, btnSend, btnEdit);
    return div;
};
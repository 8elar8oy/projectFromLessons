import { sendRequest } from './getUsers';
const BASE_URL = 'http://localhost:3000';

export const patchUsers = (pathName, user) => {
    return sendRequest({
        pathName,
        baseUrl: BASE_URL,
        method: 'PATCH',
        body: user
    });
};
import { getInput } from '../../components/input';
import styles from './userForm.module.css';
import { bottom } from '../../components/bottom';
import { createUsers } from '../../api/createUser';
import { userCard } from '../../components/userCard';

const userData = {};

const getName = name => {
    userData.username = name;
};

const getLogin = login => {
    userData.name = login;
};

const getEmail = email => {
    userData.email = email;
};

const getUserData = () => {
    createUsers('users', userData)
        .then(data => {
            const users = document.getElementById('userContainer');
            users.append(userCard(data.data));
        })
        .catch(null);
};

export const getUserForm = () => {
    const form = document.createElement('form');
    form.classList.add(styles.container);
    form.append(
        getInput({ type: 'text', labelTitle: 'Имя', callBack: getName }),
        getInput({ type: 'text', labelTitle: 'Логик', callBack: getLogin }),
        getInput({ type: 'text', labelTitle: 'Email', callBack: getEmail }),
        bottom('Отправить', getUserData)
    );

    return form;
};
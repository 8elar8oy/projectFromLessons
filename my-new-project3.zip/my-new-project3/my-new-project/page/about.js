export const aboutPage = () => {
  const div = document.createElement('div');

  return div;
};

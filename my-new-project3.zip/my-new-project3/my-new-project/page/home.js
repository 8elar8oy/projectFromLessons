import { getUsers } from '../api/getUsers';
import { userCard } from '../components/userCard';
import styles from './homePage.module.css';


export const homePage = () => {
    const div = document.createElement('div');
    div.classList.add(styles.container);
    div.setAttribute('id', 'userContainer')

    getUsers('users').then(data =>
        data.data.map(user => div.append(userCard(user)))
    );
    return div;
};
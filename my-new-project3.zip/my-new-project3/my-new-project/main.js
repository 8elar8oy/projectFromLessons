import './style.css';
import { getHeader } from './feathers/header/header';
import { getLayout } from './feathers/layout/layout';
import { getUserForm } from './feathers/userForm/getUserForm';

const app = document.querySelector('#app');

app.append(getHeader());
app.append(getUserForm());
app.append(getLayout());
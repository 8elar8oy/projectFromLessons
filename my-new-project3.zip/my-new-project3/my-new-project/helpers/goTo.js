export const goTo = (path) => {
    window.location.pathname = path
}
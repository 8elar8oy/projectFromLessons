import { bottom } from './bottom';
import { goTo } from '../helpers/goTo';

const navList = [
  {
    path: '/',
    name: 'Домашняя'
  },
  {
    path: '/about',
    name: 'О нас'
  }
];

export const getNav = () => {
  const ul = document.createElement('ul');
  const li = document.createElement('li');
  navList.forEach(navItem => {
    li.append(bottom(navItem.name, () => goTo(navItem.path)));
    ul.append(li);
  });
  return ul;
};

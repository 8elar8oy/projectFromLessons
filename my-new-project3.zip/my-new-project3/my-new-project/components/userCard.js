import styles from './userCard.module.css';
import { bottom } from "./bottom";
import { removeUser } from "../api/removeUser.js";
import {userData} from "../feathers/userForm/getUserForm";



export const userCard = user => {
    const div = document.createElement('div');
    const name = document.createElement('p');
    const login = document.createElement('p');
    const email = document.createElement('p');

    const btnDelete = bottom('удалить')
    btnDelete.addEventListener('click', () => {
        removeUser('users', user.id).then((res) => {
            const removeItem = document.getElementById(res.data.id)
            const userContainer = document.getElementById('userContainer')
            userContainer.removeChild(removeItem)
        })
    })
    const btnEdit = bottom('редактировать')


    btnEdit.addEventListener('click', () => {
                const name1 = document.getElementById('name')
                const login1 = document.getElementById('login')
                const email1 = document.getElementById('email')
                name1.value = user.name
                login1.value = user.username
                email1.value = user.email;
                userData.getId(user.id)
        })

    div.setAttribute('id', user.id)
    div.classList.add(styles.container);
    name.classList.add(styles.name);
    btnDelete.classList.add(styles.btn)
    btnEdit.classList.add(styles.btn)
    name.innerText = user.name;
    login.innerText = user.username;
    email.innerText = user.email;
    div.append( btnDelete,name, login, email, btnEdit);
    return div;
};
export const getInput = ({ type, labelTitle, callBack,id }) => {
  const input = document.createElement('input');
  const label = document.createElement('label');

  input.setAttribute('type', type);
  input.setAttribute('id',id)
  input.addEventListener('change', event => callBack(event.target.value));

  label.innerText = labelTitle;
  label.append(input);

  return label;
};

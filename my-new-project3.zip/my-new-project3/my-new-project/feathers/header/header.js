import './header.css';
import { getLogo } from '../../components/logo';
import { getNav } from '../../components/nav';

export const getHeader = () => {
  const header = document.createElement('header');
  header.classList.add('header');
  header.append(getLogo());
  header.append(getNav());
  return header;
};

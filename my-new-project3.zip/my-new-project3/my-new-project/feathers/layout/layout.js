import {homePage} from "../../page/home";
import {aboutPage} from "../../page/about";

export const getLayout = () => {
    const div = document.createElement('div')

    if (window.location.pathname === '/') {
        div.append(homePage());
    }

    if (window.location.pathname === '/about') {
        div.append(aboutPage());
    }

    return div
}
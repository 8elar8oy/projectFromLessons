import { getInput } from '../../components/input';
import styles from './userForm.module.css';
import { bottom } from '../../components/bottom';
import { createUsers } from '../../api/createUser';
import { userCard } from '../../components/userCard';
import {patchUsers} from "../../api/patchUsers";
import {getUsers} from "../../api/getUsers";

export const userData = {
    id: '',
    getId(id) {
        this.id = id
    }
};

const getName = name => {
    userData.username = name;
};

const getLogin = login => {
    userData.name = login;
};

const getEmail = email => {
    userData.email = email;
};

const getUserData = () => {

    if (userData.id){
    //console.log(userData)
       patchUsers('users',userData,userData.id ).then(data => console.log(data.data)).then((res) => {

           const userContainer = document.getElementById('userContainer')

       })
        cleanUserForm(getUserForm().id)
       return
    }
        createUsers('users', userData)
            .then(data => {
                const users = document.getElementById('userContainer');
                users.append(userCard(data.data));
                cleanUserForm(getUserForm().id)
            })
            .catch(null);


};
const cleanUserForm = (id) =>{
    const form1 = document.getElementById(id)
    form1.reset()

}
export const getUserForm = () => {
    const form = document.createElement('form');
    form.setAttribute('id','userId')
    form.classList.add(styles.container);

    form.append(
        getInput({ type: 'text', labelTitle: 'Имя', callBack: getName,id: 'name'}),
        getInput({ type: 'text', labelTitle: 'Логик', callBack: getLogin,id:'login' }),
        getInput({ type: 'text', labelTitle: 'Email', callBack: getEmail,id: 'email' }),
        bottom('Отправить', getUserData)
    );

    return form;
};